package com.example.bookingapp.tests;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;

import com.example.bookingapp.dto.BookingRefResponse;
import com.example.bookingapp.entity.BookingRequest;
import com.example.bookingapp.service.BookingService;

import reactor.core.publisher.Mono;

@SpringBootTest
@AutoConfigureWebTestClient

public class BookingControllerTests {

    @Autowired
    private WebTestClient webTestClient;

    @MockBean
    private BookingService bookingService;

    @Test
    public void testCreateBooking() {
        BookingRequest request = new BookingRequest(/* provide necessary data */);
        BookingRefResponse response = new BookingRefResponse("957000002");

        when(bookingService.createBooking(any(BookingRequest.class))).thenReturn(Mono.just(response));

        webTestClient.post()
                .uri("/api/bookings")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(request)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.bookingRef").isEqualTo("957000002");
    }
}
