package com.example.bookingapp.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.bookingapp.dto.AvailabilityResponse;
import com.example.bookingapp.dto.BookingRefResponse;
import com.example.bookingapp.entity.BookingRequest;
import com.example.bookingapp.service.BookingService;

import reactor.core.publisher.Mono;

@RestController
public class BookingController {

    private final BookingService bookingService;

    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }

    @PostMapping("/api/bookings/checkAvailability")
    public Mono<AvailabilityResponse> checkAvailability(@RequestBody BookingRequest request) {
        return bookingService.checkAvailability(request);
    }
    @PostMapping("/api/bookings")
    public Mono<BookingRefResponse> createBooking(@RequestBody BookingRequest request) {
        return bookingService.createBooking(request);
    }
}
