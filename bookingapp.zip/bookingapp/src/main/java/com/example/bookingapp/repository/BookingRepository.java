package com.example.bookingapp.repository;

import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Repository;

import com.example.bookingapp.dto.ContainerType;
import com.example.bookingapp.entity.BookingRequest;

import reactor.core.publisher.Mono;


@Repository
public interface BookingRepository extends ReactiveMongoRepository<BookingRequest, String> {

	@Query("{ containerSize: ?0, containerType: ?1 }")
    Mono<Integer> countAvailableSpace(Integer containerSize, ContainerType containerType);
    Mono<String> saveBooking(BookingRequest request, String bookingRef);
    

}
