package com.example.bookingapp.entity;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import com.example.bookingapp.dto.ContainerType;

public class BookingRequest {

    @Min(20)
    @Max(40)
    private Integer containerSize;

    private ContainerType containerType;

    @NotEmpty
    @Size(min = 5, max = 20)
    private String origin;

    @NotEmpty
    @Size(min = 5, max = 20)
    private String destination;

    @Min(1)
    @Max(100)
    private Integer quantity;

	public Integer getContainerSize() {
		return containerSize;
	}

	public void setContainerSize(Integer containerSize) {
		this.containerSize = containerSize;
	}

	public ContainerType getContainerType() {
		return containerType;
	}

	public void setContainerType(ContainerType containerType) {
		this.containerType = containerType;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

   
}
