package com.example.bookingapp.dto;

public enum ContainerType {
    DRY,
    REEFER
}
