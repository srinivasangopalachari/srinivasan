package com.example.bookingapp.dto;
public class BookingRefResponse {

    private String bookingRef;

    public BookingRefResponse(String bookingRef) {
        this.bookingRef = bookingRef;
    }

    public String getBookingRef() {
        return bookingRef;
    }

    public void setBookingRef(String bookingRef) {
        this.bookingRef = bookingRef;
    }
}
