package com.example.bookingapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.example.bookingapp.dto.AvailabilityResponse;
import com.example.bookingapp.dto.BookingRefResponse;
import com.example.bookingapp.entity.BookingRequest;
import com.example.bookingapp.repository.BookingRepository;

import reactor.core.publisher.Mono;

@Service
public class BookingService {

    private final WebClient webClient;
    private final BookingRepository bookingRepository;
    private static final String BOOKING_REF_PREFIX = "957";



    public BookingService(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.baseUrl("https://maersk.com/api/bookings").build();
		this.bookingRepository = null;
    }

    @Autowired
    public BookingService(BookingRepository bookingRepository) {
        this.webClient = null;
		this.bookingRepository = bookingRepository;
    }

    public Mono<BookingRefResponse> createBooking(BookingRequest request) {
        String bookingRef = generateBookingReference();

        return bookingRepository.saveBooking(request, bookingRef)
                .map(savedBookingRef -> new BookingRefResponse(savedBookingRef))
                .retry(4);
    }

    private String generateBookingReference() {
       
        return BOOKING_REF_PREFIX + getNextBookingNumber();
    }

    private static int bookingCounter = 1;

    private synchronized String getNextBookingNumber() {
        return String.format("%06d", bookingCounter++);
    }
    public Mono<AvailabilityResponse> checkAvailability(BookingRequest request) {
        return bookingRepository.countAvailableSpace(request.getContainerSize(), request.getContainerType())
                .map(availableSpace -> {
                    boolean isAvailable = availableSpace > 0;
                    return new AvailabilityResponse(isAvailable);
                });
    }
    
    


}
