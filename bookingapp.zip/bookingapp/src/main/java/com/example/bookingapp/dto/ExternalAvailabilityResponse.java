package com.example.bookingapp.dto;
public class ExternalAvailabilityResponse {

    private int availableSpace;

	public int getAvailableSpace() {
		return availableSpace;
	}

	public void setAvailableSpace(int availableSpace) {
		this.availableSpace = availableSpace;
	}

    
}
